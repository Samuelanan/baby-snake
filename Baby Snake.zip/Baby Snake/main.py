from graphics import Canvas
import time
import random

CANVAS_WIDTH = 400
CANVAS_HEIGHT = 400
SIZE = 20
DELAY = 0.1

def animate(canvas, player, goal):
    direction = "right"

    while True:
        # Check for key press
        key = canvas.get_last_key_press()
        if key == 'ArrowLeft':
            direction = "left"
        elif key == 'ArrowRight':
            direction = "right"
        elif key == 'ArrowUp':
            direction = "up"
        elif key == 'ArrowDown':
            direction = "down"

        # Move the player in the chosen direction
        if direction == "right":
            canvas.move(player, SIZE, 0)
        elif direction == "left":
            canvas.move(player, -SIZE, 0)
        elif direction == "up":
            canvas.move(player, 0, -SIZE)
        elif direction == "down":
            canvas.move(player, 0, SIZE)

        # Check for collisions with the goal
        if goal_reached(canvas, player, goal):
            move_goal(canvas, goal)

        # Check for out-of-bounds
        if out_of_bounds(canvas, player):
            print("Game Over!")
            break

        time.sleep(DELAY)

def out_of_bounds(canvas, player):
    x = canvas.get_left_x(player)
    y = canvas.get_top_y(player)
    return x < 0 or x >= CANVAS_WIDTH or y < 0 or y >= CANVAS_HEIGHT

def goal_reached(canvas, player, goal):
    return canvas.get_left_x(player) == canvas.get_left_x(goal) and canvas.get_top_y(player) == canvas.get_top_y(goal)

def move_goal(canvas, goal):
    new_goal_x = random.randint(0, CANVAS_WIDTH // SIZE - 1) * SIZE
    new_goal_y = random.randint(0, CANVAS_HEIGHT // SIZE - 1) * SIZE
    canvas.moveto(goal, new_goal_x, new_goal_y)

def main():
    canvas = Canvas(CANVAS